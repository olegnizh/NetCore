﻿namespace HelloPythagoras
{
    public class HelloPythagoras
    {
        public double Pythagoras(double sideLengthA, double sideLengthB)
        {
            double squaredLength = sideLengthA * sideLengthA + sideLengthB * sideLengthB;
            return squaredLength;
        }
    }
}
