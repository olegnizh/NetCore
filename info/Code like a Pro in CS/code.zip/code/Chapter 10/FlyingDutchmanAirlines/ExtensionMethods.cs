﻿namespace FlyingDutchmanAirlines
{
    internal static class ExtensionMethods
    {
        internal static bool IsPositive(this int input)
        {
            return input >= 0;
        }
    }
}
