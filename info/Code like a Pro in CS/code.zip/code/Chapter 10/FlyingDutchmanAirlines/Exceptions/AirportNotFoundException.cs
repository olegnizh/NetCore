﻿using System;

namespace FlyingDutchmanAirlines.Exceptions
{
    public class AirportNotFoundException : Exception
    {
    }
}
