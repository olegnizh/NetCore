﻿using System;

namespace FlyingDutchmanAirlines.Exceptions
{
    public class FlightNotFoundException : Exception
    {
    }
}
