﻿using System;

namespace FlyingDutchmanAirlines.Exceptions
{
    public class CouldNotAddEntityToDatabaseException : Exception
    {
    }
}
