﻿namespace FlyingDutchmanAirlinesExisting.Objects
{
    public class Booking
    {
        public string OriginAirportIATA;
        public string DestinationAirportIATA;
        public string Name;
    }
}
