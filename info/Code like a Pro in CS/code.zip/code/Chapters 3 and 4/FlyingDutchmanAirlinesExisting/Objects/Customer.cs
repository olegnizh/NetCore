﻿namespace FlyingDutchmanAirlinesExisting.Objects
{
    public class Customer
    {
        public int CustomerID;
        public string Name;

        public Customer(int customerID, string name)
        {
            CustomerID = customerID;
            Name = name;
        }
    }
}


