﻿namespace FlyingDutchmanAirlinesExisting.ReturnViews
{
    public class FlightReturnView
    {
        public int FlightNumber;
        public string Origin;
        public string Destination;
    }
}