Chapter 8: Introduction to Object-Oriented Programming
