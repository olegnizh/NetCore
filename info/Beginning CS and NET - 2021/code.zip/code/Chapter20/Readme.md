Source code for Chapter 20
