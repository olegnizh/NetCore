﻿using System;

namespace Ch09ClassLib
{
    public class MyExternalClass
    {
    }
}
