﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ch09ClassLib
{
    internal class MyInternalClass
    {
    }
}
