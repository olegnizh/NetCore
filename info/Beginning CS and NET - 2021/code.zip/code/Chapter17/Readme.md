Source code for Chapter 17
