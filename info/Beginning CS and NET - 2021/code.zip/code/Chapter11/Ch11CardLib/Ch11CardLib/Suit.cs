﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ch11CardLib
{
    public enum Suit
    {
        Club,
        Diamond,
        Heart,
        Spade
    }
}