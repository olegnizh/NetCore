﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ch11CardLib
{
    public enum Rank
    {
        Ace = 1,
        Duece,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King
    }
}