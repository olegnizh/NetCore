package eu.sig.training.ch07;

public interface CloudStorage {

}