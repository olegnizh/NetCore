package eu.sig.training.ch06.advanceddigitalcamera;

public class Video {

}
