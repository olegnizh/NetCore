package eu.sig.training.ch03.binarytree;

@SuppressWarnings("serial")
public class TreeException extends RuntimeException {
    public TreeException(String msg) {
        super(msg);
    }
}