package eu.sig.training.ch06.simpledigitalcamera;

public class SDK {

    public static SimpleDigitalCamera getCamera() {
        return new DigitalCamera();
    }

}