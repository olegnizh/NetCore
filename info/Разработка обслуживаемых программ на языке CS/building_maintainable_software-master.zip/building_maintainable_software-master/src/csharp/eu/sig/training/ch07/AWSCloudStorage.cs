﻿namespace eu.sig.training.ch07
{
    public class AWSCloudStorage : ICloudStorage
    {
        public AWSCloudStorage(long sizeGb)
        {
        }
    }
}
