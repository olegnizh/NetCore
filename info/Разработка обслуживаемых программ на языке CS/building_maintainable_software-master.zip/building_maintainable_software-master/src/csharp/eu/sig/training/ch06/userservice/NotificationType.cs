namespace eu.sig.training.ch06.userservice
{

    public class NotificationType
    {
        public static NotificationType FromString(string type)
        {
            return new NotificationType();
        }
    }

}
